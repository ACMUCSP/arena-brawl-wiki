#ifndef NETWORK_SETTINGS_HPP_
#define NETWORK_SETTINGS_HPP_

#include <SFML/Network.hpp>
#include <cstdlib>

const sf::IpAddress get_ip() {
  if (std::getenv("ARENA_BRAWL") != NULL)
    return sf::IpAddress("host.docker.internal");
  else
    return sf::IpAddress::getLocalAddress();
}

namespace net{

const uint16_t NET_PORT = 55001;
const sf::IpAddress SERVER_IP = get_ip();

}

#endif//NETWORK_SETTINGS_HPP_
