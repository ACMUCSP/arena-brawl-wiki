#ifndef SHARED_BOT_DATA_STRUCT_
#define SHARED_BOT_DATA_STRUCT_

#include <SFML/Network.hpp>
#include <vector>

namespace evab{

struct ElementInfo{
  float x_position, y_position, direction;
  int player_id;
  ElementInfo(float _x, float _y, float _direction, int id) :
      x_position(_x), y_position(_y), direction(_direction), player_id(id) {}
};

struct EvabBotPackage{
  std::vector<ElementInfo> players;
  std::vector<ElementInfo> bullets;
  bool isAlive;
  int ammo;
};

struct EvabBotActions {
  float newAircraftRotation;
  bool moving;
  bool attacking;
};

struct PlayerResponse {
  EvabBotActions action;
  int id;
};

sf::Packet& operator<<(sf::Packet& packet, const  EvabBotActions& rpacket){
  return packet << rpacket.newAircraftRotation << rpacket.moving << rpacket.attacking;
}

sf::Packet& operator>>(sf::Packet& packet,  EvabBotActions& rpacket){
  return packet >> rpacket.newAircraftRotation >> rpacket.moving >> rpacket.attacking;
}

sf::Packet& operator<<(sf::Packet& packet, const EvabBotPackage& rpacket){
  packet << (int) rpacket.players.size();
  for (const ElementInfo &player : rpacket.players) {
    packet << player.x_position << player.y_position << player.direction << player.player_id;
  }
  packet << (int) rpacket.bullets.size();
  for (const ElementInfo &bullet : rpacket.bullets) {
    packet << bullet.x_position << bullet.y_position << bullet.direction << bullet.player_id;
  }
  packet << rpacket.isAlive;
  packet << rpacket.ammo;
  return packet;
}

sf::Packet& operator>>(sf::Packet& packet, EvabBotPackage& rpacket){
  float x, y, direction;
  int id, cnt;
  packet >> cnt;
  for (int i = 0; i < cnt; ++i) {
    packet >> x >> y >> direction >> id;
    rpacket.players.push_back(ElementInfo(x, y, direction, id));
  }
  packet >> cnt;
  for (int i = 0; i < cnt; ++i) {
    packet >> x >> y >> direction >> id;
    rpacket.bullets.push_back(ElementInfo(x, y, direction, id));
  }
  packet >> rpacket.isAlive;
  packet >> rpacket.ammo;
  return packet;
}

}

#endif//SHARED_BOT_DATA_STRUCT_
